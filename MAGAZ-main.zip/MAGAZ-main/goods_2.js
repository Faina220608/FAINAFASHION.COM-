const GOODS_2 = [{ // меняем название массива
	id: 201,
    name: 'Шлёпа',
	price: 100,
	imgSrc: 'goods/shlepa.png',
}, {
	id: 202,
	name: 'Капибара',
	price: 100,
	imgSrc: 'goods/kapibara.png',
}, {
	id: 203,
	name: 'Тяги',
	price: 100,
	imgSrc: 'goods/tyagi.png',
}, {
	id: 204,
	name: 'Блинный Кот',
	price: 100,
	imgSrc: 'goods/blin.png',
}, {
	id: 205,
	name: 'Смекалочка',
	price: 100,
	imgSrc: 'goods/smekalochka.png',
}, {
	id: 206,
	name: 'Доктор Ливси',
	price: 100,
	imgSrc: 'goods/doctor livesey.png',
}, {
	id: 207,
	name: 'машинка',
	price: 100,
	imgSrc: 'goods/car.png',
}];