const GOODS = [{
	id: 101,
    name: 'Шлёпа',
	price: 111,
	imgSrc: 'goods/shlepa.png',
}, {
	id: 102,
	name: 'Капибара',
	price: 222,
	imgSrc: 'goods/kapibara.png',
}, {
	id: 103,
	name: 'Тяги',
	price: 333,
	imgSrc: 'goods/tyagi.png',
}, {
	id: 104,
	name: 'Блинный Кот',
	price: 444,
	imgSrc: 'goods/blin.png',
}, {
	id: 105,
	name: 'Смекалочка',
	price: 555,
	imgSrc: 'goods/smekalochka.png',
}, {
	id: 106,
	name: 'Доктор Ливси',
	price: 666,
	imgSrc: 'goods/doctor livesey.png',
}, {
	id: 107,
	name: 'машинка',
	price: 1000000000,
	imgSrc: 'goods/car.png',
}, {
	id: 108,
    name: 'Шлёпа',
	price: 111,
	imgSrc: 'goods/shlepa.png',
}, {
	id: 109,
	name: 'Капибара',
	price: 222,
	imgSrc: 'goods/kapibara.png',
}, {
	id: 110,
	name: 'Тяги',
	price: 333,
	imgSrc: 'goods/tyagi.png',
}, {
	id: 111,
	name: 'Блинный Кот',
	price: 444,
	imgSrc: 'goods/blin.png',
}, {
	id: 112,
	name: 'Смекалочка',
	price: 555,
	imgSrc: 'goods/smekalochka.png',
}, {
	id: 113,
	name: 'Доктор Ливси',
	price: 666,
	imgSrc: 'goods/doctor livesey.png',
}, {
	id: 114,
	//name: 'машинка',
	//price: 1000000000,
	//imgSrc: 'goods/car.png',
}];